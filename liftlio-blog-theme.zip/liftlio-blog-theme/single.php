<?php
/**
 * The template for displaying all single posts
 *
 * @package Liftlio_Blog
 */

get_header();
?>

<!-- Main Content - White Background -->
<main class="site-content">
    <div class="container">
        <div class="single-post-container">
            <?php
            while (have_posts()) :
                the_post();
                ?>
                
                <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                    <header class="post-header">
                        <?php
                        $category = liftlio_blog_primary_category();
                        if ($category) :
                            ?>
                            <a href="<?php echo esc_url(get_category_link($category->term_id)); ?>" class="blog-category">
                                <?php echo esc_html($category->name); ?>
                            </a>
                        <?php endif; ?>
                        
                        <h1 class="post-title"><?php the_title(); ?></h1>
                        
                        <div class="post-meta">
                            <span><?php the_author(); ?></span>
                            <span>•</span>
                            <time datetime="<?php echo get_the_date('c'); ?>">
                                <?php echo get_the_date(); ?>
                            </time>
                            <span>•</span>
                            <span><?php echo liftlio_blog_reading_time(); ?></span>
                        </div>
                    </header>
                    
                    <?php if (has_post_thumbnail()) : ?>
                        <div class="post-featured-image">
                            <?php the_post_thumbnail('large'); ?>
                        </div>
                    <?php endif; ?>
                    
                    <div class="post-content">
                        <?php
                        the_content();
                        
                        wp_link_pages(array(
                            'before' => '<div class="page-links">' . __('Pages:', 'liftlio-blog'),
                            'after'  => '</div>',
                        ));
                        ?>
                    </div>
                    
                    <footer class="post-footer">
                        <?php
                        $tags_list = get_the_tag_list('', ', ');
                        if ($tags_list) :
                            ?>
                            <div class="post-tags">
                                <span><?php _e('Tags:', 'liftlio-blog'); ?></span>
                                <?php echo $tags_list; ?>
                            </div>
                        <?php endif; ?>
                        
                        <!-- Post Navigation -->
                        <nav class="post-navigation">
                            <?php
                            the_post_navigation(array(
                                'prev_text' => '<span class="nav-subtitle">' . __('Previous:', 'liftlio-blog') . '</span> <span class="nav-title">%title</span>',
                                'next_text' => '<span class="nav-subtitle">' . __('Next:', 'liftlio-blog') . '</span> <span class="nav-title">%title</span>',
                            ));
                            ?>
                        </nav>
                    </footer>
                </article>
                
                <?php
                // If comments are open or we have at least one comment, load up the comment template
                if (comments_open() || get_comments_number()) :
                    comments_template();
                endif;
                
            endwhile;
            ?>
        </div>
    </div>
</main>

<?php
get_footer();
?>