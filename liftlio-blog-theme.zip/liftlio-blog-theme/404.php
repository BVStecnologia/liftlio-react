<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package Liftlio_Blog
 */

get_header();
?>

<!-- 404 Hero Section -->
<section class="blog-hero">
    <div class="container">
        <h1 class="blog-title"><?php _e('404 - Page Not Found', 'liftlio-blog'); ?></h1>
        <p class="blog-subtitle"><?php _e('Oops! That page can\'t be found.', 'liftlio-blog'); ?></p>
    </div>
</section>

<!-- Main Content - White Background -->
<main class="site-content">
    <div class="container">
        <div class="single-post-container">
            <div class="error-404 not-found">
                <div class="page-content">
                    <p><?php _e('It looks like nothing was found at this location. Maybe try one of the links below or a search?', 'liftlio-blog'); ?></p>
                    
                    <div class="search-form-container">
                        <?php get_search_form(); ?>
                    </div>
                    
                    <div class="widget widget_recent_entries">
                        <h2 class="widget-title"><?php _e('Recent Posts', 'liftlio-blog'); ?></h2>
                        <ul>
                            <?php
                            $recent_posts = wp_get_recent_posts(array(
                                'numberposts' => 5,
                                'post_status' => 'publish',
                            ));
                            
                            foreach ($recent_posts as $post) :
                                ?>
                                <li>
                                    <a href="<?php echo get_permalink($post['ID']); ?>">
                                        <?php echo $post['post_title']; ?>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    
                    <div class="widget widget_categories">
                        <h2 class="widget-title"><?php _e('Most Used Categories', 'liftlio-blog'); ?></h2>
                        <ul>
                            <?php
                            wp_list_categories(array(
                                'orderby'    => 'count',
                                'order'      => 'DESC',
                                'show_count' => 1,
                                'title_li'   => '',
                                'number'     => 10,
                            ));
                            ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<?php
get_footer();
?>