<?php
/**
 * The template for displaying the footer
 *
 * @package Liftlio_Blog
 */
?>

<!-- Footer -->
<footer class="site-footer">
    <div class="container">
        <div class="footer-content">
            <div class="footer-brand">
                <h3><?php bloginfo('name'); ?></h3>
                <p><?php echo get_theme_mod('footer_description', 'AI-powered platform to scale word-of-mouth recommendations without paying for ads.'); ?></p>
            </div>
            
            <?php if (is_active_sidebar('footer-1')) : ?>
                <div class="footer-column">
                    <?php dynamic_sidebar('footer-1'); ?>
                </div>
            <?php else : ?>
                <div class="footer-column">
                    <h4><?php _e('Product', 'liftlio-blog'); ?></h4>
                    <ul class="footer-links">
                        <li><a href="/features"><?php _e('Features', 'liftlio-blog'); ?></a></li>
                        <li><a href="/pricing"><?php _e('Pricing', 'liftlio-blog'); ?></a></li>
                        <li><a href="/api"><?php _e('API', 'liftlio-blog'); ?></a></li>
                    </ul>
                </div>
            <?php endif; ?>
            
            <?php if (is_active_sidebar('footer-2')) : ?>
                <div class="footer-column">
                    <?php dynamic_sidebar('footer-2'); ?>
                </div>
            <?php else : ?>
                <div class="footer-column">
                    <h4><?php _e('Company', 'liftlio-blog'); ?></h4>
                    <ul class="footer-links">
                        <li><a href="/about"><?php _e('About', 'liftlio-blog'); ?></a></li>
                        <li><a href="/blog"><?php _e('Blog', 'liftlio-blog'); ?></a></li>
                        <li><a href="/careers"><?php _e('Careers', 'liftlio-blog'); ?></a></li>
                    </ul>
                </div>
            <?php endif; ?>
            
            <?php if (is_active_sidebar('footer-3')) : ?>
                <div class="footer-column">
                    <?php dynamic_sidebar('footer-3'); ?>
                </div>
            <?php else : ?>
                <div class="footer-column">
                    <h4><?php _e('Legal', 'liftlio-blog'); ?></h4>
                    <ul class="footer-links">
                        <li><a href="/privacy"><?php _e('Privacy', 'liftlio-blog'); ?></a></li>
                        <li><a href="/terms"><?php _e('Terms', 'liftlio-blog'); ?></a></li>
                        <li><a href="/security"><?php _e('Security', 'liftlio-blog'); ?></a></li>
                    </ul>
                </div>
            <?php endif; ?>
        </div>
        
        <div class="footer-bottom">
            <p>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. <?php _e('All rights reserved.', 'liftlio-blog'); ?></p>
        </div>
    </div>
</footer>

<?php wp_footer(); ?>

</body>
</html>