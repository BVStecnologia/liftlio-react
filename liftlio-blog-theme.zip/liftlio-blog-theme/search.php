<?php
/**
 * The template for displaying search results pages
 *
 * @package Liftlio_Blog
 */

get_header();
?>

<!-- Search Results Hero Section -->
<section class="blog-hero">
    <div class="container">
        <h1 class="blog-title">
            <?php
            /* translators: %s: search query. */
            printf(esc_html__('Search Results for: %s', 'liftlio-blog'), '<span>' . get_search_query() . '</span>');
            ?>
        </h1>
    </div>
</section>

<!-- Main Content - White Background -->
<main class="site-content">
    <div class="container">
        <?php if (have_posts()) : ?>
            <!-- Blog Grid -->
            <div class="blog-grid">
                <?php
                while (have_posts()) :
                    the_post();
                    ?>
                    <article id="post-<?php the_ID(); ?>" <?php post_class('blog-card'); ?>>
                        <?php if (has_post_thumbnail()) : ?>
                            <div class="blog-image">
                                <a href="<?php the_permalink(); ?>">
                                    <?php the_post_thumbnail('medium_large'); ?>
                                </a>
                            </div>
                        <?php else : ?>
                            <div class="blog-image">
                                <a href="<?php the_permalink(); ?>"></a>
                            </div>
                        <?php endif; ?>
                        
                        <div class="blog-content">
                            <?php
                            $category = liftlio_blog_primary_category();
                            if ($category) :
                                ?>
                                <a href="<?php echo esc_url(get_category_link($category->term_id)); ?>" class="blog-category">
                                    <?php echo esc_html($category->name); ?>
                                </a>
                            <?php endif; ?>
                            
                            <h2 class="blog-card-title">
                                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                            </h2>
                            
                            <div class="blog-excerpt">
                                <?php the_excerpt(); ?>
                            </div>
                            
                            <div class="blog-meta">
                                <div class="author-avatar">
                                    <?php echo get_avatar(get_the_author_meta('ID'), 32); ?>
                                </div>
                                <span><?php the_author(); ?></span>
                                <span>•</span>
                                <span><?php echo liftlio_blog_reading_time(); ?></span>
                            </div>
                        </div>
                    </article>
                <?php endwhile; ?>
            </div>
            
            <!-- Pagination -->
            <div class="pagination">
                <?php
                echo paginate_links(array(
                    'prev_text' => '←',
                    'next_text' => '→',
                    'mid_size'  => 2,
                ));
                ?>
            </div>
            
        <?php else : ?>
            <div class="no-posts">
                <h2><?php _e('No results found', 'liftlio-blog'); ?></h2>
                <p><?php _e('Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'liftlio-blog'); ?></p>
                
                <div class="search-form-container">
                    <?php get_search_form(); ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</main>

<?php
get_footer();
?>