<?php
/**
 * Liftlio Blog Theme Functions
 * 
 * @package Liftlio_Blog
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Theme Setup
 */
function liftlio_blog_setup() {
    // Add theme support
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'script',
        'style',
    ));
    
    // Add custom logo support
    add_theme_support('custom-logo', array(
        'height'      => 50,
        'width'       => 200,
        'flex-height' => true,
        'flex-width'  => true,
    ));
    
    // Register navigation menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'liftlio-blog'),
        'footer'  => __('Footer Menu', 'liftlio-blog'),
    ));
    
    // Add theme support for selective refresh for widgets
    add_theme_support('customize-selective-refresh-widgets');
    
    // Add support for editor styles
    add_theme_support('editor-styles');
    
    // Add support for responsive embeds
    add_theme_support('responsive-embeds');
}
add_action('after_setup_theme', 'liftlio_blog_setup');

/**
 * Enqueue scripts and styles
 */
function liftlio_blog_scripts() {
    // Theme stylesheet
    wp_enqueue_style('liftlio-blog-style', get_stylesheet_uri(), array(), '1.0.0');
    
    // Google Fonts - Inter
    wp_enqueue_style('liftlio-blog-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap', array(), null);
    
    // Theme scripts
    wp_enqueue_script('liftlio-blog-navigation', get_template_directory_uri() . '/assets/js/navigation.js', array(), '1.0.0', true);
    
    // Comment reply script
    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'liftlio_blog_scripts');

/**
 * Register widget areas
 */
function liftlio_blog_widgets_init() {
    register_sidebar(array(
        'name'          => __('Blog Sidebar', 'liftlio-blog'),
        'id'            => 'sidebar-1',
        'description'   => __('Add widgets here to appear in your blog sidebar.', 'liftlio-blog'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));
    
    register_sidebar(array(
        'name'          => __('Footer Widget Area 1', 'liftlio-blog'),
        'id'            => 'footer-1',
        'description'   => __('Add widgets here to appear in your footer.', 'liftlio-blog'),
        'before_widget' => '<div id="%1$s" class="footer-widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="footer-widget-title">',
        'after_title'   => '</h4>',
    ));
    
    register_sidebar(array(
        'name'          => __('Footer Widget Area 2', 'liftlio-blog'),
        'id'            => 'footer-2',
        'description'   => __('Add widgets here to appear in your footer.', 'liftlio-blog'),
        'before_widget' => '<div id="%1$s" class="footer-widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="footer-widget-title">',
        'after_title'   => '</h4>',
    ));
    
    register_sidebar(array(
        'name'          => __('Footer Widget Area 3', 'liftlio-blog'),
        'id'            => 'footer-3',
        'description'   => __('Add widgets here to appear in your footer.', 'liftlio-blog'),
        'before_widget' => '<div id="%1$s" class="footer-widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="footer-widget-title">',
        'after_title'   => '</h4>',
    ));
}
add_action('widgets_init', 'liftlio_blog_widgets_init');

/**
 * Custom excerpt length
 */
function liftlio_blog_excerpt_length($length) {
    return 20;
}
add_filter('excerpt_length', 'liftlio_blog_excerpt_length');

/**
 * Custom excerpt more
 */
function liftlio_blog_excerpt_more($more) {
    return '...';
}
add_filter('excerpt_more', 'liftlio_blog_excerpt_more');

/**
 * Add reading time to posts
 */
function liftlio_blog_reading_time() {
    $content = get_post_field('post_content', get_the_ID());
    $word_count = str_word_count(strip_tags($content));
    $reading_time = ceil($word_count / 200); // Assuming 200 words per minute
    
    if ($reading_time == 1) {
        return '1 min read';
    } else {
        return $reading_time . ' min read';
    }
}

/**
 * Custom category colors
 */
function liftlio_blog_category_color($category_slug) {
    $colors = array(
        'marketing-strategy' => '#6366f1',
        'case-study' => '#ec4899',
        'industry-insights' => '#10b981',
        'ai-technology' => '#f59e0b',
        'product-updates' => '#8b5cf6',
        'default' => '#6366f1'
    );
    
    return isset($colors[$category_slug]) ? $colors[$category_slug] : $colors['default'];
}

/**
 * Get primary category
 */
function liftlio_blog_primary_category($post_id = null) {
    if (!$post_id) {
        $post_id = get_the_ID();
    }
    
    $categories = get_the_category($post_id);
    
    if (!empty($categories)) {
        return $categories[0];
    }
    
    return false;
}

/**
 * Custom comment form
 */
function liftlio_blog_comment_form_fields($fields) {
    $commenter = wp_get_current_commenter();
    $req = get_option('require_name_email');
    $aria_req = ($req ? " aria-required='true'" : '');
    
    $fields['author'] = '<p class="comment-form-author">' .
        '<input id="author" name="author" type="text" placeholder="' . __('Your Name', 'liftlio-blog') . ($req ? ' *' : '') . '" value="' . esc_attr($commenter['comment_author']) . '" size="30"' . $aria_req . ' /></p>';
    
    $fields['email'] = '<p class="comment-form-email">' .
        '<input id="email" name="email" type="email" placeholder="' . __('Your Email', 'liftlio-blog') . ($req ? ' *' : '') . '" value="' . esc_attr($commenter['comment_author_email']) . '" size="30"' . $aria_req . ' /></p>';
    
    $fields['url'] = '<p class="comment-form-url">' .
        '<input id="url" name="url" type="url" placeholder="' . __('Your Website', 'liftlio-blog') . '" value="' . esc_attr($commenter['comment_author_url']) . '" size="30" /></p>';
    
    return $fields;
}
add_filter('comment_form_default_fields', 'liftlio_blog_comment_form_fields');

/**
 * Customize the comment form
 */
function liftlio_blog_comment_form_defaults($defaults) {
    $defaults['comment_field'] = '<p class="comment-form-comment"><textarea id="comment" name="comment" cols="45" rows="8" placeholder="' . __('Your Comment', 'liftlio-blog') . '" aria-required="true"></textarea></p>';
    $defaults['title_reply'] = __('Leave a Comment', 'liftlio-blog');
    $defaults['label_submit'] = __('Post Comment', 'liftlio-blog');
    
    return $defaults;
}
add_filter('comment_form_defaults', 'liftlio_blog_comment_form_defaults');

/**
 * Add CTA button to menu
 */
function liftlio_blog_add_menu_cta($items, $args) {
    if ($args->theme_location == 'primary') {
        $items .= '<li class="menu-item menu-item-cta"><a href="/get-started" class="btn-cta">Get Started</a></li>';
    }
    return $items;
}
add_filter('wp_nav_menu_items', 'liftlio_blog_add_menu_cta', 10, 2);

/**
 * Disable emojis
 */
function liftlio_blog_disable_emojis() {
    remove_action('wp_head', 'print_emoji_detection_script', 7);
    remove_action('admin_print_scripts', 'print_emoji_detection_script');
    remove_action('wp_print_styles', 'print_emoji_styles');
    remove_action('admin_print_styles', 'print_emoji_styles');
    remove_filter('the_content_feed', 'wp_staticize_emoji');
    remove_filter('comment_text_rss', 'wp_staticize_emoji');
    remove_filter('wp_mail', 'wp_staticize_emoji_for_email');
}
add_action('init', 'liftlio_blog_disable_emojis');

/**
 * Remove unnecessary meta tags
 */
remove_action('wp_head', 'rsd_link');
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'wp_generator');
remove_action('wp_head', 'start_post_rel_link');
remove_action('wp_head', 'index_rel_link');
remove_action('wp_head', 'adjacent_posts_rel_link');
remove_action('wp_head', 'wp_shortlink_wp_head');

/**
 * Include custom template functions
 */
require get_template_directory() . '/inc/template-functions.php';
require get_template_directory() . '/inc/template-tags.php';

?>