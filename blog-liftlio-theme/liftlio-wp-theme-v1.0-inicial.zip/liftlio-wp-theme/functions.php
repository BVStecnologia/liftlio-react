<?php
/**
 * Liftlio Blog Theme Functions
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Theme setup
function liftlio_theme_setup() {
    // Add support for post thumbnails
    add_theme_support('post-thumbnails');
    
    // Add support for automatic feed links
    add_theme_support('automatic-feed-links');
    
    // Add support for title tag
    add_theme_support('title-tag');
    
    // Add support for HTML5
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
    ));
    
    // Register navigation menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'liftlio-blog'),
        'footer' => __('Footer Menu', 'liftlio-blog'),
    ));
    
    // Add support for custom logo
    add_theme_support('custom-logo', array(
        'height' => 100,
        'width' => 300,
        'flex-height' => true,
        'flex-width' => true,
    ));
}
add_action('after_setup_theme', 'liftlio_theme_setup');

// Enqueue scripts and styles
function liftlio_enqueue_scripts() {
    // Enqueue Google Fonts
    wp_enqueue_style('liftlio-google-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap', array(), null);
    
    // Enqueue theme stylesheet
    wp_enqueue_style('liftlio-style', get_stylesheet_uri(), array(), '1.0.0');
    
    // Enqueue comment reply script if needed
    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'liftlio_enqueue_scripts');

// Register widget areas
function liftlio_widgets_init() {
    register_sidebar(array(
        'name' => __('Sidebar', 'liftlio-blog'),
        'id' => 'sidebar-1',
        'description' => __('Add widgets here to appear in your sidebar.', 'liftlio-blog'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget' => '</section>',
        'before_title' => '<h2 class="widget-title">',
        'after_title' => '</h2>',
    ));
    
    register_sidebar(array(
        'name' => __('Footer Widget Area', 'liftlio-blog'),
        'id' => 'footer-1',
        'description' => __('Add widgets here to appear in your footer.', 'liftlio-blog'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h4 class="widget-title">',
        'after_title' => '</h4>',
    ));
}
add_action('widgets_init', 'liftlio_widgets_init');

// Custom excerpt length
function liftlio_excerpt_length($length) {
    return 20;
}
add_filter('excerpt_length', 'liftlio_excerpt_length');

// Custom excerpt more
function liftlio_excerpt_more($more) {
    return '...';
}
add_filter('excerpt_more', 'liftlio_excerpt_more');

// Get first category
function liftlio_get_first_category($post_id = null) {
    if (!$post_id) {
        $post_id = get_the_ID();
    }
    
    $categories = get_the_category($post_id);
    if (!empty($categories)) {
        return $categories[0];
    }
    
    return null;
}

// Custom read time calculation
function liftlio_get_reading_time($post_id = null) {
    if (!$post_id) {
        $post_id = get_the_ID();
    }
    
    $content = get_post_field('post_content', $post_id);
    $word_count = str_word_count(strip_tags($content));
    $minutes = ceil($word_count / 200); // Average reading speed
    
    return $minutes . ' min read';
}

// Add custom image sizes
add_image_size('liftlio-blog-thumbnail', 350, 200, true);

// Disable WordPress emoji
function liftlio_disable_emojis() {
    remove_action('wp_head', 'print_emoji_detection_script', 7);
    remove_action('admin_print_scripts', 'print_emoji_detection_script');
    remove_action('wp_print_styles', 'print_emoji_styles');
    remove_action('admin_print_styles', 'print_emoji_styles');
    remove_filter('the_content_feed', 'wp_staticize_emoji');
    remove_filter('comment_text_rss', 'wp_staticize_emoji');
    remove_filter('wp_mail', 'wp_staticize_emoji_for_email');
}
add_action('init', 'liftlio_disable_emojis');

// Security: Remove WordPress version
remove_action('wp_head', 'wp_generator');

// Security: Disable XML-RPC
add_filter('xmlrpc_enabled', '__return_false');

// Security: Remove unnecessary headers
remove_action('wp_head', 'rsd_link');
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'wp_shortlink_wp_head');
remove_action('wp_head', 'rest_output_link_wp_head', 10);
remove_action('wp_head', 'wp_oembed_add_discovery_links', 10);

// Include custom nav walker
require_once get_template_directory() . '/inc/nav-walker.php';