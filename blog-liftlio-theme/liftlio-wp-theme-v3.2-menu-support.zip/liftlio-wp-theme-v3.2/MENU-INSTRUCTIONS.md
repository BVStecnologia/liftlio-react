# Instruções para Configurar o Menu - Liftlio Theme v3.2

## O que foi adicionado na v3.2
- Suporte completo para menus do WordPress
- Menu dropdown/submenu funcionando
- Fallback automático quando não há menu configurado
- Estilos responsivos para mobile

## Como Configurar o Menu no WordPress

### 1. Criar um novo menu
1. Acesse **WordPress Admin → Aparência → Menus**
2. Clique em **"Criar um novo menu"**
3. Digite um nome para o menu (ex: "Menu Principal")
4. Clique em **"Criar Menu"**

### 2. Adicionar itens ao menu
1. Na coluna esquerda, você verá:
   - **Páginas** - Adicione páginas existentes
   - **Posts** - Adicione posts específicos
   - **Links Personalizados** - Adicione links externos
   - **Categorias** - Adicione categorias do blog

2. Marque os itens desejados e clique em **"Adicionar ao Menu"**

### 3. Organizar o menu
- **Arraste e solte** para reordenar os itens
- **Arraste para a direita** para criar submenus (dropdown)
- Clique na seta ao lado de cada item para editar:
  - Texto de navegação
  - Atributos do título
  - Classes CSS (veja abaixo)

### 4. Criar um botão CTA (Call to Action)
1. Adicione um **Link Personalizado**
2. URL: `https://app.liftlio.com` (ou outro link)
3. Texto do link: "Get Started"
4. Clique na seta para expandir opções
5. Se não vê "Classes CSS", clique em **"Opções de Tela"** no topo e marque **"Classes CSS"**
6. No campo **Classes CSS**, adicione: `menu-item-cta`
7. Isso transformará o link em um botão com gradiente

### 5. Ativar o menu
1. Em **"Configurações do menu"**, marque:
   - ✅ **Primary Menu** (Menu Principal)
2. Clique em **"Salvar Menu"**

## Estrutura de Menu Recomendada
```
- Home
- Features
- Pricing  
- Blog
- About
  - Our Story (submenu)
  - Team (submenu)
  - Mission (submenu)
- Contact
- Get Started (com classe menu-item-cta)
```

## Solução de Problemas

### Menu não aparece?
- Verifique se marcou "Primary Menu" nas configurações
- Certifique-se de que salvou o menu
- Limpe o cache do navegador

### Submenus não funcionam?
- Os submenus aparecem ao passar o mouse
- No mobile, será necessário adicionar JavaScript para toggle (não incluído)

### Estilo do botão CTA não funciona?
- Verifique se adicionou a classe `menu-item-cta`
- A classe deve ser adicionada sem aspas
- Limpe o cache do navegador

## Notas Técnicas
- O tema usa um Walker customizado (`Liftlio_Nav_Walker`)
- Fallback automático mostra menu padrão se nenhum menu for configurado
- CSS responsivo já incluído
- Suporte para múltiplos níveis de submenu